import pandas as pd
from pathlib import Path
 
path = Path(
    r"silver_news\data\silver\news_by_ticker"
)
 
files = list(path.rglob("*.parquet"))
 
print("Parquet files found:", len(files))
 
for file in files[:2]:
    df = pd.read_parquet(file)
 
    print("\nFile:", file)
    print(df[["ticker", "ingested_at"]].head(5).to_string(index=False))