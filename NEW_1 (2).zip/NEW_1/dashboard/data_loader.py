"""
FinTel Gold Dashboard - Data Access Layer

Reads:
    data/gold/sentiment_price              (Delta, with Parquet fallback)
    data/audit/gold_aggregation_audit.jsonl

All timestamps are converted from UTC to Asia/Kolkata and returned
timezone-naive so pandas/plotly comparisons stay simple.
"""

import json
import sys
from pathlib import Path

import pandas as pd
import streamlit as st

# =========================================================
# PATH RESOLUTION
# =========================================================

ROOT = Path(__file__).resolve().parents[1]

DISPLAY_TZ = "Asia/Kolkata"


def _resolve_paths():
    """
    Prefer paths from config/settings.py so the dashboard can never
    drift from what the pipeline actually writes. Fall back to the
    conventional layout if settings is unavailable.
    """
    gold = ROOT / "data" / "gold" / "sentiment_price"
    audit = ROOT / "data" / "audit" / "gold_aggregation_audit.jsonl"

    try:
        if str(ROOT) not in sys.path:
            sys.path.insert(0, str(ROOT))
        from config import settings  # noqa

        if getattr(settings, "GOLD_PATH", None):
            gold = Path(str(settings.GOLD_PATH))

        audit_dir = getattr(settings, "AUDIT_DIR", None) or getattr(
            settings, "AUDIT_PATH", None
        )
        if audit_dir:
            audit = Path(str(audit_dir)) / "gold_aggregation_audit.jsonl"

    except Exception:
        pass  # settings not importable from the dashboard venv - fine

    return gold, audit


GOLD_PATH, AUDIT_PATH = _resolve_paths()

TIME_COLS = ["window_start", "window_end", "computed_at"]

NUMERIC_COLS = [
    "article_count", "avg_sentiment", "min_sentiment",
    "price_first", "price_last", "price_high", "price_low",
    "price_change_pct", "price_range_pct", "tick_count",
    "day_change_pct",
]

NEWS_COLS = [
    "article_count", "avg_sentiment", "min_sentiment",
    "latest_headline", "latest_sentiment_label",
]


# =========================================================
# HELPERS
# =========================================================

def _to_local(series: pd.Series) -> pd.Series:
    """Parse to UTC, convert to display tz, drop tz info."""
    s = pd.to_datetime(series, errors="coerce", utc=True)
    return s.dt.tz_convert(DISPLAY_TZ).dt.tz_localize(None)


def _read_raw() -> tuple[pd.DataFrame, str | None]:
    """Read the Gold table. Returns (df, error_message)."""
    if not GOLD_PATH.exists():
        return pd.DataFrame(), f"Gold path does not exist:\n{GOLD_PATH}"

    delta_err = None

    try:
        from deltalake import DeltaTable
        df = DeltaTable(str(GOLD_PATH)).to_pandas()
        if not df.empty:
            return df, None
    except Exception as exc:
        delta_err = f"{type(exc).__name__}: {exc}"

    files = sorted(GOLD_PATH.rglob("*.parquet"))
    if not files:
        return pd.DataFrame(), (
            f"No parquet files found under:\n{GOLD_PATH}\n"
            f"Delta reader said: {delta_err or 'returned 0 rows'}"
        )

    try:
        df = pd.concat((pd.read_parquet(f) for f in files), ignore_index=True)
    except Exception as exc:
        return pd.DataFrame(), f"Parquet fallback failed: {exc}"

    if df.empty:
        return df, "Gold table exists but contains 0 rows."

    return df, None


# =========================================================
# GOLD TABLE
# =========================================================

@st.cache_data(ttl=20, show_spinner=False)
def load_gold(hours_back=None) -> pd.DataFrame:
    """
    Load the Gold table.

    hours_back = None  -> no time filter (All time)
    hours_back = int   -> keep rows whose window_end is within N hours

    If the filter would return nothing but data exists, the full table is
    returned and a warning is stashed in session_state.
    """
    st.session_state.pop("_gold_error", None)
    st.session_state.pop("_gold_warning", None)

    df, err = _read_raw()

    if err:
        st.session_state["_gold_error"] = err
        return pd.DataFrame()

    # ---- types ----
    for col in TIME_COLS:
        if col in df.columns:
            df[col] = _to_local(df[col])

    for col in NUMERIC_COLS:
        if col in df.columns:
            df[col] = pd.to_numeric(df[col], errors="coerce")

    if "alert_flag" in df.columns:
        df["alert_flag"] = df["alert_flag"].fillna(False).astype(bool)
    else:
        df["alert_flag"] = False

    for col in ("latest_headline", "latest_sentiment_label", "alert_reason"):
        if col not in df.columns:
            df[col] = None

    df = df.dropna(subset=["window_end"])

    if df.empty:
        st.session_state["_gold_error"] = "All rows had an unparseable window_end."
        return df

    df = df.sort_values("window_end").reset_index(drop=True)

    # ---- time filter ----
    if hours_back is None:
        return df

    cutoff = pd.Timestamp.now() - pd.Timedelta(hours=hours_back)
    filtered = df[df["window_end"] >= cutoff]

    if filtered.empty:
        newest = df["window_end"].max()
        st.session_state["_gold_warning"] = (
            f"No windows in the last {hours_back}h. "
            f"Showing all {len(df):,} rows instead. "
            f"Newest window: {newest:%d-%m-%Y %H:%M}."
        )
        return df

    return filtered.reset_index(drop=True)


# =========================================================
# DERIVED VIEWS
# =========================================================

def latest_per_symbol(df: pd.DataFrame) -> pd.DataFrame:
    """Most recent closed window for each symbol."""
    if df.empty:
        return df
    return (
        df.sort_values("window_end")
          .groupby("symbol", as_index=False)
          .tail(1)
          .sort_values("symbol")
          .reset_index(drop=True)
    )


def dedupe_timeseries(df: pd.DataFrame, freq: str = "1min") -> pd.DataFrame:
    """
    Sliding windows (5 min / 1 min slide) place each tick in 5 rows.
    Collapse to one row per symbol per interval so charts are not spiky.
    """
    if df.empty:
        return pd.DataFrame()

    out = df.copy()
    out["ts"] = out["window_end"].dt.floor(freq)

    agg = {
        "price": ("price_last", "mean"),
        "price_open": ("price_first", "first"),
        "price_high": ("price_high", "max"),
        "price_low": ("price_low", "min"),
        "change_pct": ("price_change_pct", "mean"),
        "range_pct": ("price_range_pct", "mean"),
        "ticks": ("tick_count", "sum"),
    }

    if "avg_sentiment" in out.columns:
        agg["sentiment"] = ("avg_sentiment", "mean")
    if "article_count" in out.columns:
        agg["articles"] = ("article_count", "sum")

    return (
        out.groupby(["symbol", "ts"], as_index=False)
           .agg(**agg)
           .sort_values("ts")
           .reset_index(drop=True)
    )


def news_coverage(df: pd.DataFrame) -> dict:
    """
    Detect whether the news side of the stream-stream join produced
    anything. Used to hide sentiment panels gracefully.
    """
    if df.empty:
        return {"has_news": False, "matched_rows": 0, "total_rows": 0, "pct": 0.0}

    total = len(df)

    if "article_count" in df.columns:
        matched = int((df["article_count"].fillna(0) > 0).sum())
    elif "avg_sentiment" in df.columns:
        matched = int(df["avg_sentiment"].notna().sum())
    else:
        matched = 0

    return {
        "has_news": matched > 0,
        "matched_rows": matched,
        "total_rows": total,
        "pct": round(100 * matched / total, 1) if total else 0.0,
    }


def price_activity(df: pd.DataFrame) -> dict:
    """Detect a frozen / replayed tick feed (all OHLC values identical)."""
    if df.empty:
        return {"is_moving": True, "flat_pct": 0.0}

    needed = {"price_high", "price_low", "price_first"}
    if not needed.issubset(df.columns):
        return {"is_moving": True, "flat_pct": 0.0}

    flat = (df["price_high"] == df["price_low"]).sum()
    pct = round(100 * flat / len(df), 1)
    return {"is_moving": pct < 95.0, "flat_pct": pct}


def pipeline_status(df: pd.DataFrame, live_minutes: int = 20) -> dict:
    """Infer whether the Gold pipeline is currently producing data."""
    if df.empty:
        return {"state": "OFFLINE", "age_min": None, "last": None}

    last = df["window_end"].max()
    age_min = (pd.Timestamp.now() - last).total_seconds() / 60.0

    if age_min <= live_minutes:
        state = "LIVE"
    elif age_min <= 120:
        state = "STALE"
    else:
        state = "OFFLINE"

    return {"state": state, "age_min": age_min, "last": last}


# =========================================================
# AUDIT LOG
# =========================================================

@st.cache_data(ttl=20, show_spinner=False)
def load_audit(limit: int = 500) -> pd.DataFrame:
    """Read the tail of the Gold audit JSONL file."""
    if not AUDIT_PATH.exists():
        return pd.DataFrame()

    rows = []
    try:
        with open(AUDIT_PATH, "r", encoding="utf-8") as fh:
            for line in fh:
                line = line.strip()
                if not line:
                    continue
                try:
                    rows.append(json.loads(line))
                except json.JSONDecodeError:
                    continue
    except Exception:
        return pd.DataFrame()

    if not rows:
        return pd.DataFrame()

    df = pd.DataFrame(rows[-limit:])

    for col in ("window_start_min", "window_end_max", "ts", "timestamp", "created_at"):
        if col in df.columns:
            df[col] = _to_local(df[col])

    for col in ("input_news_count", "input_tick_count", "output_row_count",
                "late_records", "duration_ms", "batch_id"):
        if col in df.columns:
            df[col] = pd.to_numeric(df[col], errors="coerce").fillna(0).astype("int64")

    return df.reset_index(drop=True)


def paths_info() -> dict:
    """Expose resolved paths for the sidebar diagnostics panel."""
    return {
        "root": str(ROOT),
        "gold": str(GOLD_PATH),
        "gold_exists": GOLD_PATH.exists(),
        "audit": str(AUDIT_PATH),
        "audit_exists": AUDIT_PATH.exists(),
        "timezone": DISPLAY_TZ,
    }