"""
FinTel Gold Dashboard

Run:
    streamlit run dashboard/app.py

Reads the Gold Delta table written by the FinTel Gold streaming job.
The pipeline does NOT need to be running - the dashboard reads
committed files from disk.
"""

import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
import streamlit as st

from data_loader import (
    load_gold,
    load_audit,
    latest_per_symbol,
    dedupe_timeseries,
    news_coverage,
    price_activity,
    pipeline_status,
    paths_info,
)

# =========================================================
# PAGE CONFIG
# =========================================================

st.set_page_config(
    page_title="FinTel | Sentiment & Price",
    layout="wide",
    initial_sidebar_state="expanded",
)

st.markdown(
    """
    <style>
      .block-container {padding-top: 2rem; padding-bottom: 3rem;}
      [data-testid="stMetricValue"] {font-size: 1.55rem;}
      [data-testid="stMetricLabel"] {font-size: 0.82rem; opacity: 0.75;}
      div[data-testid="stDataFrame"] {border-radius: 8px;}
    </style>
    """,
    unsafe_allow_html=True,
)

RANGE_OPTIONS = {
    "Last 1 hour": 1,
    "Last 6 hours": 6,
    "Last 24 hours": 24,
    "Last 3 days": 72,
    "Last 7 days": 168,
    "Last 30 days": 720,
    "All time": None,
}


# =========================================================
# SIDEBAR
# =========================================================

st.sidebar.title("FinTel Controls")

range_choice = st.sidebar.selectbox(
    "Time range",
    list(RANGE_OPTIONS.keys()),
    index=len(RANGE_OPTIONS) - 1,          # default: All time
)
hours = RANGE_OPTIONS[range_choice]

auto = st.sidebar.toggle("Auto-refresh", value=False)
interval = st.sidebar.select_slider(
    "Refresh every (s)",
    options=[10, 15, 30, 60, 120],
    value=30,
    disabled=not auto,
)

if st.sidebar.button("Refresh now", use_container_width=True):
    st.cache_data.clear()
    st.rerun()

if auto:
    st.sidebar.caption(f"Auto-refreshing every {interval}s")
    st.markdown(
        f"<meta http-equiv='refresh' content='{interval}'>",
        unsafe_allow_html=True,
    )

st.sidebar.divider()


# =========================================================
# LOAD DATA
# =========================================================

df = load_gold(hours_back=hours)

warning_msg = st.session_state.pop("_gold_warning", None)
error_msg = st.session_state.pop("_gold_error", None)

if df.empty:
    st.title("FinTel Gold Dashboard")
    st.warning("No Gold data could be loaded.")

    if error_msg:
        st.code(error_msg, language="text")

    info = paths_info()
    st.subheader("Resolved paths")
    st.dataframe(
        pd.DataFrame(
            [
                {"Item": "Project root", "Value": info["root"]},
                {"Item": "Gold path", "Value": info["gold"]},
                {"Item": "Gold exists", "Value": str(info["gold_exists"])},
                {"Item": "Audit path", "Value": info["audit"]},
                {"Item": "Audit exists", "Value": str(info["audit_exists"])},
            ]
        ),
        use_container_width=True,
        hide_index=True,
    )

    st.info(
        "With a 5-minute window and a 10-minute watermark, the first Gold "
        "rows can take roughly 15-25 minutes to appear after the pipeline "
        "starts. Run `python main.py` and wait for a `[GOLD] Batch ...` line."
    )
    st.stop()


# ---- filters ----
symbols = sorted(df["symbol"].dropna().unique().tolist())

picked = st.sidebar.multiselect("Symbols", symbols, default=symbols)
if not picked:
    picked = symbols

only_alerts = st.sidebar.checkbox("Alerts only", value=False)

view = df[df["symbol"].isin(picked)].copy()
if only_alerts:
    view = view[view["alert_flag"]]

if view.empty:
    st.warning("No rows match the current filters. Clear 'Alerts only' or add symbols.")
    st.stop()

latest = latest_per_symbol(view)
ts = dedupe_timeseries(view)

news = news_coverage(view)
prices = price_activity(view)
status = pipeline_status(df)


# ---- sidebar status ----
if status["state"] == "LIVE":
    st.sidebar.success(f"LIVE - last window {status['age_min']:.0f} min ago")
elif status["state"] == "STALE":
    st.sidebar.warning(f"STALE - last window {status['age_min']:.0f} min ago")
else:
    age_h = (status["age_min"] or 0) / 60
    st.sidebar.error(f"OFFLINE - last window {age_h:.1f} h ago")

st.sidebar.caption(f"Rows loaded: {len(df):,}  |  In view: {len(view):,}")

with st.sidebar.expander("Paths & diagnostics"):
    info = paths_info()
    st.caption(f"Gold: `{info['gold']}`")
    st.caption(f"Audit: `{info['audit']}`")
    st.caption(f"Display timezone: {info['timezone']}")
    st.caption(f"News coverage: {news['pct']}% of rows")
    st.caption(f"Flat price rows: {prices['flat_pct']}%")


# =========================================================
# HEADER
# =========================================================

st.title("FinTel - Sentiment & Price Intelligence")

st.caption(
    f"Range: {range_choice}  |  "
    f"Window span: {view['window_start'].min():%d-%m-%Y %H:%M} "
    f"to {view['window_end'].max():%d-%m-%Y %H:%M}  |  "
    f"Symbols: {view['symbol'].nunique()}"
)

if warning_msg:
    st.info(warning_msg)

if not news["has_news"]:
    st.error(
        f"**News join produced no matches** - 0 of {news['total_rows']:,} rows "
        "have articles. Sentiment panels are hidden. Likely causes: the news "
        "event-time column failed to parse, ticker symbols differ between the "
        "two Silver sources, or the news and tick time ranges do not overlap."
    )

if not prices["is_moving"]:
    st.warning(
        f"**Prices look frozen** - {prices['flat_pct']}% of windows have "
        "price_high equal to price_low. The tick feed may be replaying the "
        "same snapshot, which means price-change alerts can never fire."
    )


# =========================================================
# KPI ROW
# =========================================================

k1, k2, k3, k4, k5 = st.columns(5)

k1.metric("Symbols tracked", view["symbol"].nunique())

k2.metric("Active alerts", int(latest["alert_flag"].sum()))

if news["has_news"]:
    avg_sent = latest["avg_sentiment"].mean()
    k3.metric("Avg sentiment", f"{avg_sent:.3f}" if pd.notna(avg_sent) else "n/a")
    k4.metric("Articles in range", int(view["article_count"].fillna(0).sum()))
else:
    k3.metric("Avg sentiment", "no news")
    k4.metric("Articles in range", 0)

avg_move = latest["price_change_pct"].mean()
k5.metric("Avg price move", f"{avg_move:+.2f}%" if pd.notna(avg_move) else "n/a")

st.divider()


# =========================================================
# TABS
# =========================================================

tab_live, tab_alerts, tab_detail, tab_health = st.tabs(
    ["Live Overview", "Alert Feed", "Symbol Detail", "Pipeline Health"]
)


# ---------------------------------------------------------
# TAB 1 - LIVE OVERVIEW
# ---------------------------------------------------------
with tab_live:
    st.subheader("Current state by symbol")

    base_cols = [
        "symbol", "window_end", "price_last", "price_change_pct",
        "day_change_pct", "price_range_pct", "tick_count", "alert_flag",
    ]
    news_extra = ["avg_sentiment", "article_count", "latest_headline"]

    cols = base_cols + (news_extra if news["has_news"] else [])
    board = latest[[c for c in cols if c in latest.columns]].copy()

    col_cfg = {
        "symbol": st.column_config.TextColumn("Symbol", width="small"),
        "window_end": st.column_config.DatetimeColumn(
            "Window end", format="DD-MM-YYYY HH:mm"
        ),
        "price_last": st.column_config.NumberColumn("Price", format="%.2f"),
        "price_change_pct": st.column_config.NumberColumn("Chg %", format="%+.2f"),
        "day_change_pct": st.column_config.NumberColumn("Day %", format="%+.2f"),
        "price_range_pct": st.column_config.NumberColumn("Range %", format="%.2f"),
        "tick_count": st.column_config.NumberColumn("Ticks"),
        "alert_flag": st.column_config.CheckboxColumn("Alert"),
        "avg_sentiment": st.column_config.ProgressColumn(
            "Sentiment", min_value=-1.0, max_value=1.0, format="%.2f"
        ),
        "article_count": st.column_config.NumberColumn("Articles"),
        "latest_headline": st.column_config.TextColumn("Latest headline", width="large"),
    }

    st.dataframe(
        board,
        use_container_width=True,
        hide_index=True,
        column_config={k: v for k, v in col_cfg.items() if k in board.columns},
    )

    c1, c2 = st.columns(2)

    with c1:
        st.subheader("Day change by symbol")
        if "day_change_pct" in latest.columns and latest["day_change_pct"].notna().any():
            plot_df = latest.sort_values("day_change_pct")
            fig = px.bar(
                plot_df,
                x="day_change_pct",
                y="symbol",
                orientation="h",
                color="day_change_pct",
                color_continuous_scale="RdYlGn",
                color_continuous_midpoint=0,
            )
            fig.update_layout(
                height=380,
                margin=dict(l=10, r=10, t=20, b=10),
                xaxis_title="Day change %",
                yaxis_title="",
                coloraxis_showscale=False,
            )
            st.plotly_chart(fig, use_container_width=True)
        else:
            st.info("No day-change data available.")

    with c2:
        if news["has_news"]:
            st.subheader("Sentiment heatmap")
            pivot = ts.pivot_table(
                index="symbol", columns="ts", values="sentiment", aggfunc="mean"
            )
            fig = px.imshow(
                pivot,
                color_continuous_scale="RdYlGn",
                zmin=-1, zmax=1,
                aspect="auto",
                labels=dict(color="Sentiment"),
            )
            fig.update_layout(
                height=380,
                margin=dict(l=10, r=10, t=20, b=10),
                xaxis_title="", yaxis_title="",
            )
            st.plotly_chart(fig, use_container_width=True)
        else:
            st.subheader("Tick volume by symbol")
            fig = px.bar(
                latest.sort_values("tick_count", ascending=False),
                x="symbol", y="tick_count",
            )
            fig.update_layout(
                height=380,
                margin=dict(l=10, r=10, t=20, b=10),
                xaxis_title="", yaxis_title="Ticks in window",
            )
            st.plotly_chart(fig, use_container_width=True)


# ---------------------------------------------------------
# TAB 2 - ALERT FEED
# ---------------------------------------------------------
with tab_alerts:
    st.subheader("Alert feed")

    alerts = view[view["alert_flag"]].sort_values("window_end", ascending=False)

    if alerts.empty:
        st.success("No alerts in the selected range.")
        if not news["has_news"]:
            st.caption(
                "Note: alert_flag is driven by sentiment only in the current "
                "Gold logic, so with no news matched it can never become true."
            )
    else:
        st.error(f"{len(alerts):,} alert window(s) in range")

        for _, r in alerts.head(40).iterrows():
            with st.container(border=True):
                a, b, c = st.columns([1, 1, 3])

                a.metric(
                    r["symbol"],
                    f"{r['price_last']:.2f}" if pd.notna(r["price_last"]) else "n/a",
                    f"{r['price_change_pct']:+.2f}%"
                    if pd.notna(r["price_change_pct"]) else None,
                )

                sent = r.get("avg_sentiment")
                b.metric(
                    "Sentiment",
                    f"{sent:.3f}" if pd.notna(sent) else "n/a",
                    f"{int(r.get('article_count') or 0)} articles",
                )

                c.markdown(
                    f"**{r['window_start']:%d-%m-%Y %H:%M} - "
                    f"{r['window_end']:%H:%M}**\n\n"
                    f"{r.get('alert_reason') or 'No reason recorded'}\n\n"
                    f"_{r.get('latest_headline') or 'No headline available'}_"
                )

        st.download_button(
            "Download alerts as CSV",
            alerts.to_csv(index=False).encode("utf-8"),
            file_name="fintel_alerts.csv",
            mime="text/csv",
        )


# ---------------------------------------------------------
# TAB 3 - SYMBOL DETAIL
# ---------------------------------------------------------
with tab_detail:
    left, right = st.columns([1, 1])
    sym = left.selectbox("Symbol", picked)
    chart_kind = right.radio(
        "Chart type", ["Line", "Candlestick"], horizontal=True
    )

    sub = ts[ts["symbol"] == sym]

    if sub.empty:
        st.info("No data for this symbol in the selected range.")
    else:
        fig = go.Figure()

        if chart_kind == "Candlestick":
            fig.add_trace(
                go.Candlestick(
                    x=sub["ts"],
                    open=sub["price_open"],
                    high=sub["price_high"],
                    low=sub["price_low"],
                    close=sub["price"],
                    name="Price",
                )
            )
            fig.update_layout(xaxis_rangeslider_visible=False)
        else:
            fig.add_trace(
                go.Scatter(
                    x=sub["ts"], y=sub["price"],
                    name="Price", mode="lines+markers",
                    line=dict(width=2),
                )
            )

        if news["has_news"] and "sentiment" in sub.columns:
            fig.add_trace(
                go.Scatter(
                    x=sub["ts"], y=sub["sentiment"],
                    name="Sentiment", mode="lines",
                    yaxis="y2", line=dict(width=2, dash="dot"),
                )
            )
            fig.update_layout(
                yaxis2=dict(
                    title="Sentiment", overlaying="y",
                    side="right", range=[-1, 1],
                )
            )

        fig.update_layout(
            height=520,
            title=f"{sym} - price{' vs sentiment' if news['has_news'] else ''}",
            xaxis=dict(title="Time"),
            yaxis=dict(title="Price"),
            legend=dict(orientation="h", y=1.12),
            margin=dict(l=10, r=10, t=70, b=10),
        )
        st.plotly_chart(fig, use_container_width=True)

        m1, m2, m3, m4 = st.columns(4)
        m1.metric("Windows", len(sub))
        m2.metric("High", f"{sub['price_high'].max():.2f}")
        m3.metric("Low", f"{sub['price_low'].min():.2f}")
        m4.metric("Total ticks", int(sub["ticks"].sum()))

        st.subheader("Window history")

        hist_cols = [
            "window_start", "window_end", "price_first", "price_last",
            "price_high", "price_low", "price_change_pct", "price_range_pct",
            "tick_count", "day_change_pct",
        ]
        if news["has_news"]:
            hist_cols += ["avg_sentiment", "min_sentiment", "article_count",
                          "alert_reason"]

        hist = (
            view[view["symbol"] == sym]
            .sort_values("window_end", ascending=False)
        )

        st.dataframe(
            hist[[c for c in hist_cols if c in hist.columns]].head(200),
            use_container_width=True,
            hide_index=True,
        )

        st.download_button(
            f"Download {sym} history as CSV",
            hist.to_csv(index=False).encode("utf-8"),
            file_name=f"fintel_{sym}.csv",
            mime="text/csv",
        )


# ---------------------------------------------------------
# TAB 4 - PIPELINE HEALTH
# ---------------------------------------------------------
with tab_health:
    st.subheader("Gold batch audit")

    audit = load_audit()

    if audit.empty:
        st.info(f"No audit records found at:\n\n`{paths_info()['audit']}`")
    else:
        h1, h2, h3, h4 = st.columns(4)
        h1.metric("Batches logged", len(audit))
        h2.metric("Total output rows", int(audit.get("output_row_count", pd.Series([0])).sum()))
        h3.metric("Late records", int(audit.get("late_records", pd.Series([0])).sum()))
        h4.metric("Avg trigger (ms)", int(audit.get("duration_ms", pd.Series([0])).mean()))

        c1, c2 = st.columns(2)

        if "output_row_count" in audit.columns:
            with c1:
                fig = px.line(
                    audit, x="batch_id", y="output_row_count",
                    title="Output rows per batch", markers=True,
                )
                fig.update_layout(height=320, margin=dict(l=10, r=10, t=50, b=10))
                st.plotly_chart(fig, use_container_width=True)

        if "duration_ms" in audit.columns:
            with c2:
                fig = px.line(
                    audit, x="batch_id", y="duration_ms",
                    title="Trigger duration (ms)", markers=True,
                )
                fig.update_layout(height=320, margin=dict(l=10, r=10, t=50, b=10))
                st.plotly_chart(fig, use_container_width=True)

        if {"input_news_count", "input_tick_count"}.issubset(audit.columns):
            melted = audit.melt(
                id_vars="batch_id",
                value_vars=["input_news_count", "input_tick_count"],
                var_name="source", value_name="rows",
            )
            fig = px.bar(
                melted, x="batch_id", y="rows", color="source",
                barmode="group", title="Input rows per source",
            )
            fig.update_layout(height=340, margin=dict(l=10, r=10, t=50, b=10))
            st.plotly_chart(fig, use_container_width=True)

            total_news = int(audit["input_news_count"].sum())
            if total_news == 0:
                st.error(
                    "The audit log shows **zero news input rows** across all "
                    "batches. The news stream is not delivering data to the "
                    "Gold job at all - check the News Silver path, format and "
                    "recursiveFileLookup setting."
                )

        st.subheader("Raw audit records")
        st.dataframe(audit.tail(100), use_container_width=True, hide_index=True)