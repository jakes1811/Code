TRANSACTION HISTORY - CHANGED FILES ONLY

This ZIP contains only the new or modified application files for transaction history.

Files:
1. app/repositories/transaction_repository.py  [NEW]
2. app/routers/transactions.py                [NEW]
3. app/services/holding_service.py             [MODIFIED]
4. app/main.py                                 [MODIFIED]

How to apply:
- Extract into the root of your existing portfolio_backend folder, preserving the app/... paths.
- Replace the two modified files when prompted.
- The transaction_history table is NOT included in this ZIP because you said you have already created it.
- The table should have these columns: transaction_id, portfolio_id, security_id, transaction_type,
  quantity, price, transaction_amount, transaction_date. transaction_id should be an identity/auto-generated primary key.

API:
GET /portfolios/{portfolio_id}/transactions
Example: http://localhost:8001/portfolios/1/transactions

Important:
The transaction inserts use a separate database connection from the holdings operations. For full
atomicity, the holdings change and transaction insert should later be moved into one shared DB transaction.
