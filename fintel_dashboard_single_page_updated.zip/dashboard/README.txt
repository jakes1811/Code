# FinTel dashboard update

## Files
- `dashboard/app.py` — redesigned single-page Streamlit dashboard
- `dashboard/data_loader.py` — retained existing Gold Delta/Parquet loader
- `dashboard/diagonisis.py` — retained existing diagnostics script
- `dashboard/req.txt` — retained requirements

## Install / run
1. Extract this ZIP into your FinTel project, replacing the existing `dashboard` folder after keeping a backup.
2. Activate the same virtual environment used by your dashboard.
3. Install dependencies if needed:
   `pip install -r dashboard/req.txt`
4. From the FinTel project root run:
   `streamlit run dashboard/app.py`

## Data behavior
The dashboard reads the existing Gold `sentiment_price` table. It does not create mock market data.
The Gold table currently exposes aggregated news windows, not necessarily every individual article or its publisher. The UI therefore displays the latest headline available per Gold window and does not invent publisher names.
`article_count` is a window-level count. If the Gold job uses overlapping sliding windows, summing these counts can count the same article in more than one window; the KPI is labelled “News matches” and its help text explains this.
The company selector is driven by symbols actually present in the Gold table. The all-company market overview remains visible below the selected-company panels.
