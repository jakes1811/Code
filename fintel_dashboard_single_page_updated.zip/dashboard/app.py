"""
FinTel - single-page financial news and stock dashboard.

Run from the dashboard folder:
    streamlit run app.py

The dashboard reads the existing Gold Delta/Parquet output through data_loader.py.
It does not create synthetic market or news data.
"""

import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
import streamlit as st

from data_loader import (
    load_gold,
    load_audit,
    latest_per_symbol,
    dedupe_timeseries,
    news_coverage,
    price_activity,
    pipeline_status,
    paths_info,
    news_feed,
    sentiment_badge,
)

# ---------------------------------------------------------
# PAGE CONFIG + THEME
# ---------------------------------------------------------

st.set_page_config(
    page_title="FinTel | Market & News Dashboard",
    page_icon="📈",
    layout="wide",
    initial_sidebar_state="collapsed",
)

st.markdown(
    """
    <style>
      :root { --navy:#10264b; --muted:#64748b; --line:#e2e8f0; }
      .stApp { background:#f6f8fc; color:#14233f; }
      .block-container { padding:1.15rem 1.45rem 2.5rem; max-width:1800px; }
      h1,h2,h3 { color:var(--navy); }
      h1 { font-size:1.75rem !important; font-weight:800 !important; }
      h2 { font-size:1.12rem !important; font-weight:750 !important; }
      div[data-testid="stMetric"] {
        background:#ffffff; border:1px solid var(--line); border-radius:13px;
        padding:13px 15px; box-shadow:0 1px 3px rgba(15,23,42,.04);
      }
      div[data-testid="stMetricLabel"] { color:#52627a; font-weight:650; }
      div[data-testid="stMetricValue"] { color:#10264b; font-weight:800; }
      div[data-testid="stPlotlyChart"], div[data-testid="stDataFrame"] {
        background:#fff; border:1px solid var(--line); border-radius:12px;
        padding:7px;
      }
      .panel {
        background:#fff; border:1px solid var(--line); border-radius:13px;
        padding:14px 16px; margin-bottom:8px;
      }
      .muted { color:#64748b; font-size:.82rem; }
      .news-title { color:#14233f; font-weight:700; line-height:1.35; }
      .pill {
        display:inline-block; border-radius:20px; padding:3px 9px;
        font-size:.72rem; font-weight:700;
      }
      .positive { background:#dcfce7; color:#15803d; }
      .negative { background:#fee2e2; color:#b91c1c; }
      .neutral { background:#e2e8f0; color:#475569; }
      div[data-testid="stHorizontalBlock"] { gap: .8rem; }
      hr { border-color:#e2e8f0; }
    </style>
    """,
    unsafe_allow_html=True,
)

RANGE_OPTIONS = {
    "Last 1 hour": 1,
    "Last 6 hours": 6,
    "Last 24 hours": 24,
    "Last 3 days": 72,
    "Last 7 days": 168,
    "Last 30 days": 720,
    "All available data": None,
}

COMPANY_NAMES = {
    "RELIANCE": "Reliance Industries",
    "TCS": "TCS",
    "INFY": "Infosys",
    "HDFCBANK": "HDFC Bank",
    "ICICIBANK": "ICICI Bank",
    "TATASTEEL": "Tata Steel",
    "SBIN": "State Bank of India",
    "ITC": "ITC",
    "SUNPHARMA": "Sun Pharma",
    "BHARTIARTL": "Bharti Airtel",
    "ADANIENT": "Adani Enterprises",
    "COALINDIA": "Coal India",
    "BAJFINANCE": "Bajaj Finance",
    "HINDALCO": "Hindalco Industries",
    "ONGC": "ONGC",
}


def company_name(symbol):
    """Convert common NSE ticker formats to readable company names."""
    raw = str(symbol).upper().replace(".NS", "").replace("-EQ", "")
    return COMPANY_NAMES.get(raw, raw)


def fmt_number(value, decimals=2, prefix=""):
    if pd.isna(value):
        return "—"
    return f"{prefix}{value:,.{decimals}f}"


def sentiment_class(value):
    label = sentiment_badge(value).lower()
    return label if label in ("positive", "negative") else "neutral"


def style_fig(fig, height=300):
    fig.update_layout(
        height=height,
        margin=dict(l=12, r=12, t=35, b=12),
        paper_bgcolor="white",
        plot_bgcolor="white",
        font=dict(family="Arial, sans-serif", color="#24344d", size=11),
        legend=dict(orientation="h", y=1.12, x=0),
        hovermode="x unified",
    )
    fig.update_xaxes(showgrid=False, linecolor="#dbe3ee")
    fig.update_yaxes(gridcolor="#edf1f6", zerolinecolor="#dbe3ee")
    return fig


def show_news_item(row):
    headline = row.get("latest_headline")
    headline = str(headline).strip() if pd.notna(headline) else ""
    if not headline:
        headline = "Headline not available in Gold output"

    score = row.get("avg_sentiment")
    label = row.get("latest_sentiment_label")
    label = str(label).upper() if pd.notna(label) and str(label).strip() else sentiment_badge(score)
    css = sentiment_class(score)

    ts = row.get("window_end")
    time_text = ts.strftime("%d %b %Y, %I:%M %p") if pd.notna(ts) else "Time unavailable"
    symbol = row.get("symbol", "")
    raw_count = row.get("article_count", 0)
    count = int(raw_count) if pd.notna(raw_count) else 0

    st.markdown(
        f"""
        <div class="panel">
          <div style="display:flex;justify-content:space-between;gap:10px;align-items:flex-start">
            <div style="flex:1">
              <div class="news-title">{headline}</div>
              <div class="muted" style="margin-top:6px">
                {company_name(symbol)} &nbsp; • &nbsp; {time_text}
                &nbsp; • &nbsp; {count} article(s) in this Gold window
              </div>
            </div>
            <span class="pill {css}">{label}</span>
          </div>
        </div>
        """,
        unsafe_allow_html=True,
    )


# ---------------------------------------------------------
# TOP BAR + CONTROLS
# ---------------------------------------------------------

top_left, top_right = st.columns([3.1, 1.7], vertical_alignment="center")
with top_left:
    st.markdown(
        """
        <div style="display:flex;align-items:center;gap:12px;padding:2px 0 8px">
          <span style="font-size:30px">📈</span>
          <div>
            <div style="font-size:27px;font-weight:850;color:#10264b;line-height:1.1">FinTel</div>
            <div style="font-size:13px;color:#64748b">Real-time Financial News &amp; Market Dashboard</div>
          </div>
        </div>
        """,
        unsafe_allow_html=True,
    )

with top_right:
    r1, r2 = st.columns([1.2, 1])
    with r1:
        range_choice = st.selectbox(
            "Time range", list(RANGE_OPTIONS.keys()), index=4, label_visibility="collapsed"
        )
    with r2:
        refresh_now = st.button("↻ Refresh", use_container_width=True)

if refresh_now:
    st.cache_data.clear()
    st.rerun()

hours_back = RANGE_OPTIONS[range_choice]

with st.expander("Dashboard refresh settings", expanded=False):
    auto_refresh = st.toggle("Auto-refresh dashboard", value=True)
    refresh_interval = st.select_slider(
        "Refresh interval (seconds)",
        options=[15, 30, 60, 120],
        value=30,
        disabled=not auto_refresh,
    )
    if auto_refresh:
        st.markdown(
            f"<meta http-equiv='refresh' content='{refresh_interval}'>",
            unsafe_allow_html=True,
        )

# ---------------------------------------------------------
# LOAD EXISTING GOLD DATA
# ---------------------------------------------------------

df = load_gold(hours_back=hours_back)
warning_msg = st.session_state.pop("_gold_warning", None)
error_msg = st.session_state.pop("_gold_error", None)

if df.empty:
    st.warning("No Gold data could be loaded yet.")
    if error_msg:
        st.code(error_msg, language="text")
    info = paths_info()
    st.markdown("**Resolved data locations**")
    st.write(f"Gold table: `{info['gold']}`")
    st.write(f"Gold table exists: `{info['gold_exists']}`")
    st.write(f"Audit file: `{info['audit']}`")
    st.info(
        "Start the FinTel pipeline and wait until the Gold aggregation job "
        "commits its first batch. This dashboard reads the existing Gold output."
    )
    st.stop()

required = {"symbol", "window_end"}
missing = required - set(df.columns)
if missing:
    st.error(f"Gold data is missing required columns: {', '.join(sorted(missing))}")
    st.stop()

symbols = sorted(df["symbol"].dropna().astype(str).unique().tolist())
if not symbols:
    st.warning("No stock symbols are present in the Gold data.")
    st.stop()

default_symbol = next(
    (s for s in symbols if s.upper().replace(".NS", "") == "RELIANCE"),
    symbols[0],
)

selector_col, status_col = st.columns([2.5, 3.5], vertical_alignment="bottom")
with selector_col:
    selected_symbol = st.selectbox(
        "Select company",
        symbols,
        index=symbols.index(default_symbol),
        format_func=lambda s: f"{company_name(s)} ({s})",
    )

latest_all = latest_per_symbol(df)
selected_view = df[df["symbol"].astype(str) == selected_symbol].copy()
selected_latest = latest_per_symbol(selected_view)
selected_ts = dedupe_timeseries(selected_view)
feed_all = news_feed(df, limit=1000)
feed_company = news_feed(selected_view, limit=300)

coverage = news_coverage(df)
price_health = price_activity(df)
status = pipeline_status(df)

with status_col:
    state = status["state"]
    last = status.get("last")
    last_text = last.strftime("%d %b %Y, %I:%M %p") if pd.notna(last) and last is not None else "No update"
    if state == "LIVE":
        st.success(f"● LIVE DATA  ·  Last Gold update: {last_text}")
    elif state == "STALE":
        st.warning(f"● STALE DATA  ·  Last Gold update: {last_text}")
    else:
        st.error(f"● OFFLINE  ·  Last Gold update: {last_text}")

if warning_msg:
    st.info(warning_msg)

# ---------------------------------------------------------
# KPI STRIP
# ---------------------------------------------------------

# Gold stores article counts at window level. With sliding windows these
# counts may repeat across adjacent windows, so label them as window matches.
news_matches = int(pd.to_numeric(df.get("article_count", 0), errors="coerce").fillna(0).sum()) if "article_count" in df else 0
avg_sentiment = (
    pd.to_numeric(latest_all.get("avg_sentiment"), errors="coerce").mean()
    if "avg_sentiment" in latest_all else float("nan")
)
avg_market_change = (
    pd.to_numeric(latest_all.get("day_change_pct"), errors="coerce").mean()
    if "day_change_pct" in latest_all else float("nan")
)

k1, k2, k3, k4 = st.columns(4)
k1.metric("News matches", f"{news_matches:,}", help="Sum of article_count values in Gold windows; overlapping windows may repeat matches.")
k2.metric("Stocks tracked", f"{latest_all['symbol'].nunique():,}")
k3.metric(
    "NSE Avg. Change",
    fmt_number(avg_market_change, 2, prefix="") + "%" if pd.notna(avg_market_change) else "—",
    help="Mean day_change_pct across the latest Gold row for each tracked symbol.",
)
k4.metric(
    "Avg. Sentiment",
    fmt_number(avg_sentiment, 2),
    sentiment_badge(avg_sentiment).title() if pd.notna(avg_sentiment) else "No news sentiment",
)

st.divider()

# ---------------------------------------------------------
# ROW 1: LATEST NEWS + PRICE VS NEWS
# ---------------------------------------------------------

left, right = st.columns([0.95, 1.45], gap="large")

with left:
    st.subheader(f"📰 Latest News — {company_name(selected_symbol)}")
    if feed_company.empty:
        st.info("No news-bearing Gold windows are available for this company in the selected range.")
    else:
        for _, row in feed_company.sort_values("window_end", ascending=False).head(5).iterrows():
            show_news_item(row)
        if len(feed_company) > 5:
            with st.expander(f"View {len(feed_company) - 5} more news windows"):
                for _, row in feed_company.sort_values("window_end", ascending=False).iloc[5:30].iterrows():
                    show_news_item(row)

with right:
    st.subheader(f"📊 Price vs News — {company_name(selected_symbol)}")
    if selected_ts.empty or "price" not in selected_ts.columns:
        st.info("No price time-series data is available for this company.")
    else:
        fig = go.Figure()
        fig.add_trace(
            go.Scatter(
                x=selected_ts["ts"],
                y=selected_ts["price"],
                mode="lines",
                name="Price",
                line=dict(color="#1677e8", width=2.8),
                hovertemplate="Time: %{x}<br>Price: ₹%{y:,.2f}<extra></extra>",
            )
        )

        marker_feed = feed_company.copy()
        if not marker_feed.empty and "price_last" in marker_feed:
            marker_feed = marker_feed.dropna(subset=["window_end", "price_last"])
            if not marker_feed.empty:
                marker_feed["marker_size"] = (
                    pd.to_numeric(marker_feed["article_count"], errors="coerce")
                    .fillna(1).clip(lower=1, upper=8) * 3 + 7
                )
                fig.add_trace(
                    go.Scatter(
                        x=marker_feed["window_end"],
                        y=marker_feed["price_last"],
                        mode="markers",
                        name="News",
                        marker=dict(
                            color="#8b5cf6",
                            size=marker_feed["marker_size"],
                            line=dict(color="white", width=1.5),
                        ),
                        customdata=marker_feed[["latest_headline", "article_count"]],
                        hovertemplate=(
                            "News window: %{x}<br>Price: ₹%{y:,.2f}"
                            "<br>Headline: %{customdata[0]}"
                            "<br>Articles: %{customdata[1]}<extra></extra>"
                        ),
                    )
                )
        fig.update_layout(
            height=350,
            margin=dict(l=10, r=10, t=12, b=10),
            paper_bgcolor="white",
            plot_bgcolor="white",
            font=dict(color="#24344d", size=11),
            legend=dict(orientation="h", y=1.12, x=0),
            yaxis_title="Price (₹)",
            xaxis_title="Time",
            hovermode="x unified",
        )
        fig.update_xaxes(showgrid=False)
        fig.update_yaxes(gridcolor="#edf1f6")
        st.plotly_chart(fig, use_container_width=True)
        st.caption("Purple markers indicate Gold windows containing news; they are not proof of causation.")

# ---------------------------------------------------------
# ROW 2: SENTIMENT TREND + TOP 5 STOCK MOVERS
# ---------------------------------------------------------

st.divider()
left, right = st.columns([1, 1.05], gap="large")

with left:
    st.subheader(f"💬 Sentiment Trend — {company_name(selected_symbol)}")
    if (
        selected_ts.empty
        or "sentiment" not in selected_ts.columns
        or selected_ts["sentiment"].notna().sum() == 0
    ):
        st.info("No sentiment values are available for this company in the selected range.")
    else:
        sent = selected_ts.dropna(subset=["sentiment"]).copy()
        fig = px.area(
            sent, x="ts", y="sentiment",
            markers=True,
            color_discrete_sequence=["#16a34a"],
        )
        fig.update_traces(
            line=dict(width=2.5),
            fillcolor="rgba(22,163,74,0.12)",
            marker=dict(size=5),
            hovertemplate="Time: %{x}<br>Sentiment: %{y:.3f}<extra></extra>",
        )
        fig.update_layout(
            height=290, margin=dict(l=10, r=10, t=10, b=10),
            paper_bgcolor="white", plot_bgcolor="white",
            yaxis_title="Sentiment score", xaxis_title="Time",
            yaxis=dict(range=[-1, 1], gridcolor="#edf1f6"),
            xaxis=dict(showgrid=False),
            showlegend=False,
        )
        st.plotly_chart(fig, use_container_width=True)
        st.caption("Scale: −1 (negative) to +1 (positive).")

with right:
    st.subheader("📈 Stocks Overview — Top 5 Movers")
    movers = latest_all.copy()
    if "price_change_pct" in movers:
        movers["price_change_pct"] = pd.to_numeric(movers["price_change_pct"], errors="coerce")
        movers = movers.dropna(subset=["price_change_pct"])
        movers = movers.reindex(
            movers["price_change_pct"].abs().sort_values(ascending=False).index
        ).head(5)

    if movers.empty:
        st.info("No stock price-change values are available.")
    else:
        table = pd.DataFrame({
            "Company": movers["symbol"].map(company_name),
            "Symbol": movers["symbol"],
            "Price (₹)": pd.to_numeric(movers.get("price_last"), errors="coerce").round(2),
            "Change %": movers["price_change_pct"].round(2),
            "Sentiment": movers.get("avg_sentiment", pd.Series(index=movers.index, dtype=float)).apply(sentiment_badge),
        })
        st.dataframe(
            table,
            use_container_width=True,
            hide_index=True,
            height=255,
            column_config={
                "Price (₹)": st.column_config.NumberColumn(format="₹%.2f"),
                "Change %": st.column_config.NumberColumn(format="%+.2f%%"),
            },
        )
        st.caption("Top five by absolute latest-window price change. The table uses all tracked symbols.")

# ---------------------------------------------------------
# ROW 3: COMPANY SNAPSHOT + SENTIMENT DISTRIBUTION
# ---------------------------------------------------------

st.divider()
left, right = st.columns([1.1, 1], gap="large")

with left:
    st.subheader(f"🏢 Company Snapshot — {company_name(selected_symbol)}")
    if selected_latest.empty:
        st.info("No latest snapshot is available.")
    else:
        row = selected_latest.iloc[-1]
        current_price = row.get("price_last", float("nan"))
        day_high = (
            pd.to_numeric(selected_view.get("price_high"), errors="coerce").max()
            if "price_high" in selected_view else float("nan")
        )
        day_low = (
            pd.to_numeric(selected_view.get("price_low"), errors="coerce").min()
            if "price_low" in selected_view else float("nan")
        )
        change = row.get("day_change_pct", row.get("price_change_pct", float("nan")))
        tick_count = (
            int(pd.to_numeric(selected_view.get("tick_count"), errors="coerce").fillna(0).sum())
            if "tick_count" in selected_view else None
        )

        s1, s2, s3, s4 = st.columns(4)
        s1.metric("Current Price", fmt_number(current_price, 2, "₹"), fmt_number(change, 2) + "%" if pd.notna(change) else None)
        s2.metric("Period High", fmt_number(day_high, 2, "₹"))
        s3.metric("Period Low", fmt_number(day_low, 2, "₹"))
        s4.metric("Ticks", f"{tick_count:,}" if tick_count is not None else "—")
        st.caption("High/low are calculated over the selected dashboard time range; ticks are Gold tick_count totals, not traded volume.")

with right:
    st.subheader(f"🍩 News Sentiment Distribution — {company_name(selected_symbol)}")
    if feed_company.empty or "avg_sentiment" not in feed_company:
        st.info("No news sentiment is available for this company.")
    else:
        scores = pd.to_numeric(feed_company["avg_sentiment"], errors="coerce").dropna()
        if scores.empty:
            st.info("News windows do not contain sentiment scores.")
        else:
            labels = scores.apply(sentiment_badge)
            counts = labels.value_counts().reindex(["POSITIVE", "NEUTRAL", "NEGATIVE"], fill_value=0)
            colors = {"POSITIVE": "#16a34a", "NEUTRAL": "#94a3b8", "NEGATIVE": "#ef4444"}
            fig = go.Figure(
                go.Pie(
                    labels=counts.index,
                    values=counts.values,
                    hole=0.62,
                    marker=dict(colors=[colors[x] for x in counts.index]),
                    textinfo="percent",
                    hovertemplate="%{label}: %{value} news windows (%{percent})<extra></extra>",
                )
            )
            fig.update_layout(
                height=285, margin=dict(l=10, r=10, t=10, b=10),
                paper_bgcolor="white", showlegend=True,
                legend=dict(orientation="v", x=1, y=0.5),
                annotations=[dict(
                    text=f"<b>{len(scores)}</b><br>Windows",
                    x=0.5, y=0.5, showarrow=False,
                    font=dict(size=16, color="#10264b"),
                )],
            )
            st.plotly_chart(fig, use_container_width=True)

# ---------------------------------------------------------
# ALL-COMPANY OVERVIEW + RECENT GOLD WINDOWS
# ---------------------------------------------------------

st.divider()
st.subheader("🌐 All Companies — Market Overview")

overview = latest_all.copy()
overview["Company"] = overview["symbol"].map(company_name)
overview_cols = [
    "Company", "symbol", "price_last", "price_change_pct",
    "day_change_pct", "article_count", "avg_sentiment", "alert_flag",
]
overview = overview[[c for c in overview_cols if c in overview.columns]].rename(
    columns={
        "symbol": "Ticker",
        "price_last": "Latest Price (₹)",
        "price_change_pct": "Window Change %",
        "day_change_pct": "Day Change %",
        "article_count": "News Count",
        "avg_sentiment": "Sentiment Score",
        "alert_flag": "Alert",
    }
)
st.dataframe(
    overview.sort_values("Day Change %", ascending=False, na_position="last")
    if "Day Change %" in overview else overview,
    use_container_width=True,
    hide_index=True,
    height=340,
    column_config={
        "Latest Price (₹)": st.column_config.NumberColumn(format="₹%.2f"),
        "Window Change %": st.column_config.NumberColumn(format="%+.2f%%"),
        "Day Change %": st.column_config.NumberColumn(format="%+.2f%%"),
        "Sentiment Score": st.column_config.NumberColumn(format="%.3f"),
        "Alert": st.column_config.CheckboxColumn(),
    },
)

# ---------------------------------------------------------
# FOOTER / DIAGNOSTICS
# ---------------------------------------------------------

audit = load_audit()
with st.expander("Pipeline health & diagnostics"):
    d1, d2, d3, d4 = st.columns(4)
    d1.metric("Gold rows loaded", f"{len(df):,}")
    d2.metric("News coverage", f"{coverage['pct']}%")
    d3.metric("Flat-price rows", f"{price_health['flat_pct']}%")
    d4.metric("Audit batches", f"{len(audit):,}")

    if not coverage["has_news"]:
        st.warning(
            "No Gold rows currently contain article matches. Check the Silver-to-Gold "
            "news input, ticker normalization, event timestamps and stream join range."
        )
    if not price_health["is_moving"]:
        st.warning(
            f"Price values may be frozen: {price_health['flat_pct']}% of checked "
            "Gold rows have identical high and low values."
        )
    if not audit.empty:
        st.dataframe(audit.tail(30), use_container_width=True, hide_index=True)
    info = paths_info()
    st.caption(f"Gold: {info['gold']}")
    st.caption(f"Audit: {info['audit']}")
    st.caption(f"Display timezone: {info['timezone']}")

st.caption(
    "FinTel dashboard · Data is read from the Gold aggregation output · "
    "News and price correlation is descriptive, not causal."
)
